import java.sql.*;

public class test {
	public static void main(String[] args) {
		String server = "jdbc:mysql://140.119.19.73:3315/";
		String database = "111304058"; // change to your own database
		String url = server + database + "?useSSL=false";
		String username = "111304058"; // change to your own user name
		String password = "gveiz"; // change to your own password　　　　

		try (Connection conn = DriverManager.getConnection(url, username, password)) {
			System.out.println("DB Connectd");
			 
			// use Connection object conn to create statement in try block
			Statement stat = conn.createStatement();
			String query;
			boolean sucess;
			
		
			query = "SELECT ID, Platform, Genre, Global_Sales FROM sales;";
			sucess = stat.execute(query);
			if (sucess) {
				ResultSet result = stat.getResultSet();
				showResultSet(result);
				result.close();
			}
			
			System.out.println("-".repeat(80));
			
			query = "SELECT ID, Platform, Genre FROM sales WHERE genre='Sports'";
			sucess = stat.execute(query);
			if (sucess) {
				ResultSet result = stat.getResultSet();
				showResultSet(result);
				result.close();
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	// define this static method in your Tester class
	public static void showResultSet(ResultSet result) throws SQLException {
		ResultSetMetaData metaData = result.getMetaData();
		int columnCount = metaData.getColumnCount();
		for (int i = 1; i <= columnCount; i++) {			
			System.out.printf("%15s", metaData.getColumnLabel(i));
		}
		System.out.println();
		
		while (result.next()) {
			for (int i = 1; i <= columnCount; i++) {
				System.out.printf("%15s", result.getString(i));
			}
			System.out.println();
		}
	}
	
}